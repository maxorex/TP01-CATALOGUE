<nav class="navbar navbar-expand-lg navbar-dark shadow-sm cart-navbar">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo e(route('home')); ?>">
            <img class="navbar-logo" src="<?php echo e(asset('images/icons/anvil.png')); ?>" alt="Icon">
            <span class="navbar-title">Blackriver Blades</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Continuer les achats</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/components/cart/nav.blade.php ENDPATH**/ ?>