<nav class="navbar navbar-expand-lg navbar-dark shadow-sm">
    <div class="container">
        <div class="collapse navbar-collapse align-items-center">
            <ul class="navbar-nav me-auto mb-0 gap-lg-3">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Accueil</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/components/navbar.blade.php ENDPATH**/ ?>