<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['css' => 'cart.css','title' => 'Panier – Blackriver Blades']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['css' => 'cart.css','title' => 'Panier – Blackriver Blades']); ?>

    <?php if (isset($component)) { $__componentOriginald6340e691528aa0bfc0ba483ac503005 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald6340e691528aa0bfc0ba483ac503005 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cart.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cart.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald6340e691528aa0bfc0ba483ac503005)): ?>
<?php $attributes = $__attributesOriginald6340e691528aa0bfc0ba483ac503005; ?>
<?php unset($__attributesOriginald6340e691528aa0bfc0ba483ac503005); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald6340e691528aa0bfc0ba483ac503005)): ?>
<?php $component = $__componentOriginald6340e691528aa0bfc0ba483ac503005; ?>
<?php unset($__componentOriginald6340e691528aa0bfc0ba483ac503005); ?>
<?php endif; ?>

    <main class="py-5 px-3 cart">
        <div class="container">
            <h1 class="mb-2">Votre panier</h1>
            <br>
            <div class="row g-4">
                <?php if(session('success')): ?>
                    <div class="alert alert-secondary ">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>

                <div class="col-lg-8">
                    <form action="<?php echo e(route('cart.modify')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="cart-panel p-4 p-lg-4">
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="d-flex justify-content-between align-items-start pb-3 mb-3 border-bottom"
                                    style="border-color: rgba(255, 140, 0, 0.1);">
                                    <div class="d-flex gap-3 flex-grow-1">

                                        <?php if($item['weapon']->imagePath): ?>
                                            <img src="images/<?php echo e($item['weapon']->imagePath); ?>"
                                                alt="<?php echo e($item['weapon']->imagePath); ?>" class="cart-item-image">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/image-not-available.png')); ?>"
                                                alt="image non disponible" class="cart-item-image">
                                        <?php endif; ?>

                                        <div class="min-w-0">
                                            <h6 class="mb-1 text-white"><?php echo e($item['weapon']->name); ?></h6>

                                            <p class="small text-secondary mb-2"><?php echo e($item['weapon']->description); ?></p>
                                            <p class="text-gradient-orange mb-0">
                                                <?php echo e($item['weapon']->price); ?> $ / Unité</p>
                                        </div>
                                    </div>

                                    <div class="text-end ms-3">
                                        <div class="d-flex gap-2 justify-content-end mb-2">

                                            <?php $__errorArgs = ['quantities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-danger"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                            <button type="button" class="btn btn-sm btn-outline-accent"
                                                data-action="decrease" style="width: 36px;">-</button>

                                            <input type="number" min="0" max="<?php echo e($item['weapon']->stock); ?>"
                                                name="quantities[<?php echo e($item['weapon']->id); ?>]"
                                                class="form-control form-control-sm text-center quantity-input"
                                                value="<?php echo e($item['quantity']); ?>" style="width: 50px;">

                                            <button type="button" class="btn btn-sm btn-outline-accent"
                                                data-action="increase" style="width: 36px;">+</button>
                                        </div>

                                        <p class="text-gradient-orange">Total: <?php echo e($item['totalProduct']); ?> $</p>

                                        <a href="<?php echo e(route('cart.delete', $item['weapon']->id)); ?>"
                                            class="btn btn-sm btn-outline-light" title="Delete">✕</a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-5 text-secondary">
                                    <h5>Votre panier est vide.</h5>
                                </div>
                            <?php endif; ?>

                            <div class="d-flex gap-2">
                                <button type="submit" name="action" value="update"
                                    class="btn btn-outline-primary flex-grow-1">Mettre à jour</button>
                                <button type="submit" name="action" value="empty"
                                    class="btn btn-outline-danger flex-grow-1">Vider le panier</button>
                            </div>
                        </div>

                    </form>
                </div>


                <!-- Résumé de la commande -->
                <div class="col-lg-4">
                    <div class="cart-panel p-4 p-lg-4 text-secondary">
                        <h5 class="mb-4">Résumé de la commande</h5>

                        <div class="d-flex justify-content-between mb-2 text-secondary">
                            <span>Sous-total</span>
                            <span class="text-gradient-orange"><?php echo e($subtotal); ?></span>
                        </div>

                        <div class="d-flex justify-content-between mb-2 text-secondary">
                            <span>Livraison</span>
                            <span class="text-gradient-orange">0.00</span>
                        </div>

                        <div class="d-flex justify-content-between mb-2 text-secondary">
                            <span>TPS (5%)</span>
                            <span class="text-gradient-orange"><?php echo e($totalTPS); ?></span>
                        </div>

                        <div class="d-flex justify-content-between mb-3 text-secondary">
                            <span>TVQ (9.975%)</span>
                            <span class="text-gradient-orange"><?php echo e($totalTVQ); ?></span>
                        </div>

                        <div class="d-flex justify-content-between border-top border-secondary pt-3 mb-4">
                            <span class="fw-bold">Total</span>
                            <span class="text-gradient-orange fw-bold fs-5"><?php echo e($total); ?></span>
                        </div>

                        <div class="d-grid gap-2 mb-2">
                            <button class="btn btn-accent">Passer à la caisse</button>
                        </div>

                        <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-accent w-100">Continuer vos achats</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/cart/index.blade.php ENDPATH**/ ?>