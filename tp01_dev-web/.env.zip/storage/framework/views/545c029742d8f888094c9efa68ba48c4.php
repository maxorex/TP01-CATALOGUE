<footer class="footer">
  <div class="container">
    <p>&copy; 2026 Blackriver Blades. Tous droits réservés.</p>
  </div>
</footer><?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/components/footer.blade.php ENDPATH**/ ?>