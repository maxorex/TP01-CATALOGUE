<div class="modal-header">
    <h1 class="modal-title fs-4 weapon-modal-title" id="exampleModalLabel"><?php echo e($weapon->name); ?></h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
    <div class="row g-4 align-items-start weapon-modal-layout">
        <div class="col-12 col-md-5">
            <div class="weapon-modal-image-wrap">
                <?php if($weapon->imagePath): ?>
                    <img src="<?php echo e(asset("images/$weapon->imagePath")); ?>" alt="<?php echo e($weapon->name); ?>"
                        class="weapon-modal-image">
                <?php else: ?>
                    <img src="<?php echo e(asset('images/image-not-available.png')); ?>" alt="image non disponible"
                        class="weapon-modal-image">
                <?php endif; ?>
            </div>
        </div>

        <div class="col-12 col-md-7">

            <p class="category-name weapon-modal-category mb-3 d-inline-block">
                <?php echo e($weapon->category->name); ?>

            </p>

            <p class="weapon-modal-description mb-3">
                <?php echo e($weapon->description); ?>

            </p>

            <p class="weapon-modal-stock mb-3">
                Stock disponible: <span><?php echo e($weapon->stock); ?></span>
            </p>

            <div class="modal-weapon-price fw-semibold"><?php echo e($weapon->price); ?> $</div>
        </div>
    </div>
</div>
<form method="POST" action="<?php echo e(route('cart.add')); ?>" class="modal-footer weapon-modal-footer">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($weapon->id); ?>">
    <button type="button" class="btn btn-outline-accent button-style" data-bs-dismiss="modal">Continuer</button>
    <button type="submit" class="btn btn-outline-accent button-style weapon-modal-add-btn">Ajouter au panier</button>
</form>
<?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/weapons/_show.blade.php ENDPATH**/ ?>