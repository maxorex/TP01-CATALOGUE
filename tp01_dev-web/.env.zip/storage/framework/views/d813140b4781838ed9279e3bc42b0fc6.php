<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    
</body>
</html><?php /**PATH C:\Cejep\TP01-CATALOGUE\tp01_dev-web\resources\views/welcome.blade.php ENDPATH**/ ?>